/* ============================================
   MONEY TANK (Squid Game style) - Heiko Dashboard
   - Ne touche pas au calcul des objectifs
   - Observe simplement le % global et anime le remplissage
   ============================================ */

(function(){
  const MAX_BILLS = 28; // performance: limite dure
  const BILL_CHAR = "💶"; // visuel léger (emoji)
  const STORAGE_KEY = "moneyTank_enabled";

  function clamp(n, min, max){ return Math.max(min, Math.min(max, n)); }

  function prefersReducedMotion(){
    return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }

  function ensureTank(){
    const rain = document.querySelector('.money-rain');
    if (!rain) return null;

    // Évite de recréer si déjà en place
    let tank = rain.querySelector('.money-tank');
    if (tank) return tank;

    rain.innerHTML = '';
    tank = document.createElement('div');
    tank.className = 'money-tank';

    const fill = document.createElement('div');
    fill.className = 'money-tank-fill';
    tank.appendChild(fill);

    rain.appendChild(tank);
    return tank;
  }

  function setFill(tank, percent){
    const fill = tank.querySelector('.money-tank-fill');
    if (!fill) return;
    fill.style.setProperty('--fill', percent + '%');
  }

  function layoutBills(tank, percent){
    const fill = tank.querySelector('.money-tank-fill');
    if (!fill) return;

    const tankRect = tank.getBoundingClientRect();
    const tankW = tankRect.width;
    const tankH = tankRect.height;
    if (!tankW || !tankH) return;

    const fillH = tankH * (percent / 100);

    // Nombre de billets proportionnel au % (plafonné)
    const desired = clamp(Math.round((percent / 100) * MAX_BILLS), 0, MAX_BILLS);

    const bills = Array.from(tank.querySelectorAll('.money-bill'));

    // Retirer si on a trop
    while (bills.length > desired){
      const b = bills.pop();
      b.remove();
    }

    // Ajouter si on n'en a pas assez
    while (bills.length < desired){
      const b = document.createElement('div');
      b.className = 'money-bill';
      b.textContent = BILL_CHAR;
      tank.appendChild(b);
      bills.push(b);

      if (!prefersReducedMotion()){
        b.style.animation = 'moneyDrop 900ms cubic-bezier(.2,.9,.2,1) both';
      }
    }

    // Positionner tous les billets dans la zone "remplie"
    // (placement pseudo-aléatoire stable basé sur l'index)
    bills.forEach((b, i) => {
      const seed = (i * 9301 + 49297) % 233280;
      const r1 = seed / 233280;
      const r2 = ((seed * 9301 + 49297) % 233280) / 233280;

      const size = 28; // approx
      const maxLeft = Math.max(0, tankW - size - 6);
      const left = Math.round(3 + r1 * maxLeft);

      const usableH = Math.max(0, fillH - size - 6);
      const bottom = Math.round(3 + (usableH > 0 ? r2 * usableH : 0));

      b.style.left = left + 'px';
      b.style.bottom = bottom + 'px';

      // Quand le % augmente, les nouveaux billets apparaissent dans la zone remplie,
      // ceux existants restent cohérents (on ne les "secoue" pas inutilement).
      b.style.opacity = '0.95';
    });
  }

  function parsePercentFromText(txt){
    if (!txt) return null;
    const m = String(txt).match(/(\d{1,3})\s*%/);
    if (!m) return null;
    const n = parseInt(m[1], 10);
    if (Number.isNaN(n)) return null;
    return clamp(n, 0, 100);
  }

  function start(){
    const tank = ensureTank();
    if (!tank) return;

    const scoreEl = document.querySelector('.global-score-value');
    if (!scoreEl) return;

    let last = null;

    const apply = () => {
      const p = parsePercentFromText(scoreEl.textContent);
      if (p === null) return;

      if (p === last) return;
      last = p;

      setFill(tank, p);
      layoutBills(tank, p);
    };

    // initial
    apply();

    // observe changements
    const obs = new MutationObserver(apply);
    obs.observe(scoreEl, { characterData: true, childList: true, subtree: true });

    // si resize, recalc positions
    window.addEventListener('resize', () => {
      if (last === null) return;
      layoutBills(tank, last);
    }, { passive: true });
  }

  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
