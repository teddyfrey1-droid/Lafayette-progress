# Lafayette-progress
Suivi des indicateurs
